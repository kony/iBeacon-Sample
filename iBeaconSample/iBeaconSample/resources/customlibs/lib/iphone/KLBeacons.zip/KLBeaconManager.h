//
//  KLBeaconManager.h
//  KLBeacon
//
//  Created by Amba on 12/01/14.
//  Copyright (c) 2014 Konylabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@class KLBeaconRegion;
@class CallBack;

/*!
 This class provides way to monitor regions and range for beacons.
 @discussion Uses CLLocationManager class to interact with iOS SDK and acts as a CLLocationManagerDelegate
 */
@interface KLBeaconManager : NSObject <CLLocationManagerDelegate>

/*!
 @abstract To get callback whtn the authorization status of the Location Services for the app changed
 :: function monitoringStartedForRegionCallback(region)
 region BeaconRegion for which the monitoring has been started.
 */
@property (nonatomic,retain) CallBack *monitoringStartedForRegionCallback;

/*!
 @abstract To get callback whtn the authorization status of the Location Services for the app changed
 :: function authorizationStatusChanged(status)
 status the authorization status
 Value os status (BeaconManagerAuthorizationStatus) is one of
 "BeaconManagerAuthorizationStatusNotDetermined"
 "BeaconManagerAuthorizationStatusRestricted"
 "BeaconManagerAuthorizationStatusDenied"
 "BeaconManagerAuthorizationStatusAuthorized"
 */
@property (nonatomic,retain) CallBack *authorizationStatusChangedCallback;

/*!
 @abstract To know the authorization status of the Location Services for the app
 @return A status of the authorization
    Value os status (BeaconManagerAuthorizationStatus) is one of
    "BeaconManagerAuthorizationStatusNotDetermined" 
    "BeaconManagerAuthorizationStatusRestricted"
    "BeaconManagerAuthorizationStatusDenied"
    "BeaconManagerAuthorizationStatusAuthorized"
 */
- (NSString *)authorizationStatus;

/*! 
 @abstract To determine if the monitoring available for beacon regions
 @return YES if available, NO otherwise
 */
- (BOOL)isMonitoringAvailableForBeaconRegions;

/*!
 @abstract To determine if the ranging available
 @return YES if available, NO otherwise
 */
- (BOOL)isRangingAvailableForBeaconRegions;

/*!
 @abstract Initializes KLBeaconManager instance with callbacks.
 
 @param monitoringCallback To get region monitoring updates.
 @param rangingCallback To get region ranging updates.
 @param errorCallback To get error callback.
 
 @return KLBeaconManager instance.
 
 @discussion Please refer monitoringCallback, rangingCallback, errorCallback for details.
 
 :: monitoringCallback Callback method for monitoring updates
 
 function monitoringCallback (klBeaconRegion, klBeaconRegionState)
 
 klBeaconRegion KLBeaconRegion being monitored
 
 klBeaconRegionState is of type string and value will be one of
 
 "BeaconRegionStateUnknown"
 "BeaconRegionStateInside"
 "BeaconRegionStateOutside"
 
 :: rangingCallback Callback method for ranging updates
 
 function rangingCallback (klBeaconRegion, klBeacons)
 
 klBeaconRegion KLBeaconRegion instance
 klBeacons array of KLBeacon instances
 
 
 :: errorCallback Callback method for getting updated on error condition
 
 function errorCallback (klBeaconManagerError, errorName, errorDictionary, klBeaconRegion)
 
 klBeaconManagerError error message string, value will be one of
 
 "BeaconManagerMonitoringError"
 "BeaconManagerRangingError"
 "BeaconManagerFailedError"
 
 errorName Name of the error
 
 errorDictionary error dictionary containing information about the error
 
 klBeaconRegion region for which error occurred (nil for BeaconManagerFailedError).
 */
- (id)initWithMonitoringCallback:(CallBack *)monitoringCallback
                 rangingCallback:(CallBack *)rangingCallback
                 andErrorCallback:(CallBack *)errorCallback;

/*!
 @abstract To retrieve the regions ranged.
 @return An array of KLBeaconRegion instances.
 
 @discussion mapped to -rangedRegions of CLLocationManager.
 */
- (NSArray *)rangedRegions;

/*!
 @abstract To retrieve the regions monitored.
 @return An array of KLBeaconRegion instances.
 
 @discussion mapped to -monitoredRegions of CLLocationManager.
 */
- (NSArray *)monitoredRegions;

/*!
 @abstract Starts monitoring for region
 @param klBeaconRegion Beacon region to monitor
 @discussion If the API is called more than once for a region, the behaviour is as is with the native framework
 @discussion mapped to -startMonitoringForRegion of CLLocationManager
 */
- (void)startMonitoringBeaconRegion:(KLBeaconRegion*)klBeaconRegion;

/*!
 @abstract Stops monitoring beacon region
 @param klBeaconRegion KLBeaconRegion instance represenging region being monitored
 @discussion mapped to -stopMonitoringForRegion of CLLocationManager
 */
- (void)stopMonitoringBeaconRegion:(KLBeaconRegion *)klBeaconRegion;

/*!
 @abstract Starts ranging for beacons in region.
 @param klBeaconRegion KLBeaconRegion instance represenging region to start ranging.
 
 @discussion mapped to -startRangingBeaconsInRegion: of CLLocationManager.
 */
- (void)startRangingBeaconsInRegion:(KLBeaconRegion *)klBeaconRegion;

/*!
 @abstract Stops ranging for beacons in region.
 @param klBeaconRegion KLBeaconRegion instance represenging ranging region.
 
 @discussion mapped to -stopRangingBeaconsInRegion: of CLLocationManager.
 */
- (void)stopRangingBeaconsInRegion:(KLBeaconRegion *)klBeaconRegion;

/*!
 @abstract Retrieves the state of a region asynchronously.
 @param klBeaconRegion KLBeaconRegion instance represenging region to determine state.
 
 @discussion Asynchronously retrieve the cached state of the specified region. The state is returned to the delegate via
 *      monitoringCallback.
 */
- (void)requestStateForRegion:(KLBeaconRegion *)klBeaconRegion;

@end

/*! @name BeaconManagerAuthorizationStatus */
/*! The user has not yet made a choice regarding whether this application can use location services.*/
extern NSString *const kBeaconManagerAuthorizationStatusNotDetermined;
/*! This application is not authorized to use location services. The user cannot change this application’s status, possibly due to active restrictions such as parental controls being in place.*/
extern NSString *const kBeaconManagerAuthorizationStatusRestricted;
/*! The user explicitly denied the use of location services for this application or location services are currently disabled in Settings.*/
extern NSString *const kBeaconManagerAuthorizationStatusDenied;
/*! This application is authorized to use location services.*/
extern NSString *const kBeaconManagerAuthorizationStatusAuthorized;

/*! @name BeaconRegionState */
/*! BeaconRegionStateUnknown : It is unknown whether the location is inside or outside of the region.*/
extern NSString *const kBeaconRegionStateUnknown;
/*! BeaconRegionStateInside : The location is inside the given region.*/
extern NSString *const kBeaconRegionStateInside;
/*! BeaconRegionStateOutside : The location is outside of the given region.*/
extern NSString *const kBeaconRegionStateOutside;

/*! @name BeaconManagerError messages */
/*! BeaconManagerMonitoringError : a region monitoring error occurred. */
extern NSString *const kBeaconManagerMonitoringError;
/*! BeaconManagerRangingError : an error occurred while gathering ranging information for a set of beacons. */
extern NSString *const kBeaconManagerRangingError;
/*! BeaconManagerFailed :  location manager was unable to retrieve a location value. */
extern NSString *const kBeaconManagerFailedError;
