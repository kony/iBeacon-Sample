//
//  KLPeripheralManager.h
//  KLBeacon
//
//  Created by Amba on 12/01/14.
//  Copyright (c) 2014 Konylabs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@class KLBeaconRegion;
@class CallBack;

/*!
 Provides way to advertise using iBeacons
 @discussion KLPeripheralManager is a wrapper class of CBPeripheralManager & acts as delegate.
 */
@interface KLPeripheralManager : NSObject <CBPeripheralManagerDelegate>

/*!
 @abstract Returns the app’s authorization status for sharing data while in the background state.
 
 @return A value indicating whether the app is authorized to share data using Bluetooth services while in the background. 
 returns a string with value one of 
 "PeripheralManagerAuthorizationStatusDetermined"
 "PeripheralManagerAuthorizationStatusRestricted"
 "PeripheralManagerAuthorizationStatusDenied"
 "PeripheralManagerAuthorizationStatusAuthorized"
 
 @discussion The authorization status of a given app is managed by the system and determined by several factors. Apps must be explicitly authorized to share data using Bluetooth services while in the background state. The system automatically displays a request for user authorization when your app first attempts to use Bluetooth services to share data.
 
 Calling this method does not prompt the user for access. Instead, you use this method to detect restricted access and simply hide any affected UI features from the user.
 */
- (NSString *)authorizationStatus;

/*!
 @abstract Initializes KLPeripheralManager with callbacks
 @param stateUpdatedCallback function stateCallback(peripheralManagerState)
    peripheralManagerState Possible values are PeripheralManagerState
 @param adStatusCallback function adStatusCallback(errorName, errorInfo)
    errorName - Name of the error if error occurred, nil otherwise
    errorInfo - Info about the error if error occurred, nil otherwise
 @return Initialized KLPeripheralManager instance
 */
- (id)initWithStateUpdatedCallback:(CallBack *)stateUpdatedCallback andAdvertisingStatusCallback:(CallBack *)adStatusCallback;

/*!
 @abstract Starts advertising beacon data with measuredPower.
 @param klBeaconRegion A beacon region, whose data to be advertised.
 @param measuredPower The received signal strength indicator (RSSI) value (measured in decibels) for the device. This value represents the measured strength of the beacon from one meter away and is used during ranging. Specify nil to use the default value for the device.
 */
- (void)startAdvertising:(KLBeaconRegion *)klBeaconRegion withMeasuredPower:(NSNumber *)measuredPower;

/*!
 @abstract Stops advertising peripheral manager data.
 @discussion Call this method when you no longer want to advertise peripheral manager data.
 */
- (void)stopAdvertising;

/*!
 @abstract To determine if the peripheral manager is currently advertising data.
 @return YES if peripheral manager is advertising any data.
 */
- (BOOL)isAdvertising;

@end

/*! @name PeripheralManagerAuthorizationStatusMessages */
/*! The user has not yet made a choice regarding whether this app can share data using Bluetooth services while in the background state. */
extern NSString *const kPeripheralManagerAuthorizationStatusNotDetermined;
/*! This app is not authorized to share data using Bluetooth services while in the background state. The user cannot change this app’s status, possibly due to active restrictions such as parental controls being in place. */
extern NSString *const kPeripheralManagerAuthorizationStatusRestricted;
/*! The user explicitly denied this app from sharing data using Bluetooth services while in the background state.*/
extern NSString *const kPeripheralManagerAuthorizationStatusDenied;
/*! This app is authorized to share data using Bluetooth services while in the background state.*/
extern NSString *const kPeripheralManagerAuthorizationStatusAuthorized;

/*! @name PeripheralManagerState */
/*! PoweredOff */
extern NSString *const kPeripheralManagerStatePoweredOff;
extern NSString *const kPeripheralManagerStatePoweredOn;
extern NSString *const kPeripheralManagerStateResetting;
extern NSString *const kPeripheralManagerStateUnauthorized;
extern NSString *const kPeripheralManagerStateUnknown;
extern NSString *const kPeripheralManagerStateUnsupported;
