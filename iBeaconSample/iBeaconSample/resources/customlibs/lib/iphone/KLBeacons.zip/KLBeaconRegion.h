//
//  KLBeaconRegion.h
//  KLBeacon
//
//  Created by Amba on 12/01/14.
//  Copyright (c) 2014 Konylabs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CLBeaconRegion;
/*! 
 Represents a beacon region, wrapper of CLBeaconRegion class
 */
@interface KLBeaconRegion : NSObject

/*!
 * @abstract The unique ID of the beacons being targeted. (read-only)
 */
@property (readonly, nonatomic) NSString *proximityUUIDString;


/*!
 * @abstract The identifier string of the beacons region. (read-only)
 */
@property (readonly, nonatomic) NSString *identifier;

/*!
 *  @abstract The value identifying a group of beacons. (read-only)
 *  @discussion If you do not specify a major value for the beacon, the value in this property is nil. When this property is nil, the major value of the beacon is ignored when determining if it is a match.
 */
@property (readonly, nonatomic) NSNumber *major;

/*!
 * @abstract The value identifying a specific beacon within a group. (read-only)
 * @discussion If you do not specify a minor value for the beacon, the value in this property is nil. When this property is nil, the minor value of the beacon is ignored when determining if it is a match.
 *
 */
@property (readonly, nonatomic) NSNumber *minor;

/*!
 *  @abstract A Boolean indicating whether beacon notifications are sent when the device’s display is on.
 *  @discussion
 *    When set to YES, the location manager sends beacon notifications when the user turns on the display and the device is already inside the region. These notifications are sent even if your app is not running. In that situation, the system launches your app into the background so that it can handle the notifications. In both situations, the location manager calls the monitoringCallback method.
 */
@property (nonatomic, assign) BOOL notifyEntryStateOnDisplay;

/*!
 @abstract Creates and returns a region object that targets a beacon with the specified proximity ID, major value, and minor value.
 @param uuidString The unique ID of the beacons being targeted. This value must not be nil.
 @param major The major value that you use to identify one or more beacons.
 @param minor The minor value that you use to identify a specific beacon.
 @param identifier A unique identifier to associate with the returned region object. You use this identifier to differentiate regions within your application. This value must not be nil.
 @return A beacon region object.
 @discussion This method creates a region that reports the beacon with the specified proximityUUID, major, and minor values.
 */
+ (KLBeaconRegion *)beaconRegionWithProximityUUID:(NSString *)uuidString  major:(NSNumber *)major minor:(NSNumber *)minor identifier:(NSString *)identifier;

/*!
 @abstract Initializes and returns a region object that targets a beacon with the specified proximity ID, major value, and minor value.
 @param uuidString The unique ID of the beacons being targeted. This value must not be nil.
 @param major The major value that you use to identify one or more beacons.
 @param minor The minor value that you use to identify a specific beacon.
 @param identifier A unique identifier to associate with the returned region object. You use this identifier to differentiate regions within your application. This value must not be nil.
 @return An initialized beacon region object.
 @discussion This method initializes a region that reports the beacon with the specified proximityUUID, major, and minor values.
 */
- (KLBeaconRegion *)initWithProximityUUID:(NSString *)uuidString  major:(NSNumber *)major minor:(NSNumber *)minor identifier:(NSString *)identifier;

@end
