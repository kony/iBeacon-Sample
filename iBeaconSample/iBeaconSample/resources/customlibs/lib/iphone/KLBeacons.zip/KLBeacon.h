//
//  KLBeacon.h
//  KLBeacon
//
//  Created by Amba on 12/01/14.
//  Copyright (c) 2014 Konylabs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CLBeacon;

/*!
 The KLBeacon class represents a beacon that was encountered during region monitoring.
 The identity of a beacon is defined by its proximityUUID, major, and minor properties.
 
 @note Wrapper class for CLBeacon.
 */
@interface KLBeacon : NSObject

/*!
 @abstract The proximity ID (string representation) of the beacon. (read-only)
 */
@property (readonly, nonatomic) NSString *proximityUUIDString;

/*!
 @abstract The most significant value in the beacon. (read-only)
 */
@property (readonly, nonatomic) NSNumber *major;

/*!
 @abstract The least significant value in the beacon. (read-only)
 */
@property (readonly, nonatomic) NSNumber *minor;

/*!
 @abstract The relative distance to the beacon. (read-only)
 @discussion value is one of
 "BeaconProximityUnknown"
 "BeaconProximityImmediate"
 "BeaconProximityNear"
 "BeaconProximityFar"
 */
@property (readonly, nonatomic) NSString *proximity;

/*!
 @abstract The accuracy of the proximity value, measured in meters from the beacon. (read-only)
 */
@property (readonly, nonatomic) double accuracy;

/*!
 @abstract The received signal strength of the beacon, measured in decibels. (read-only)
 */
@property (readonly, nonatomic) NSInteger rssi;

@end

// @name Proximity - Represents the current proximity of an entity.
/*! The proximity of the beacon could not be determined. */
extern NSString *const kBeaconProximityUnknown;
/*! The beacon is in the user’s immediate vicinity. */
extern NSString *const kBeaconProximityImmediate;
/*! The beacon is relatively close to the user. */
extern NSString *const kBeaconProximityNear;
/*! The beacon is far away. */
extern NSString *const kBeaconProximityFar;
